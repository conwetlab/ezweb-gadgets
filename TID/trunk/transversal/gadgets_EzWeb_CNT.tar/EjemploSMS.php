 <?php

include "APISMS.php";

$sms = new MensajeriaWeb();

$log = "639839273";	# MSISDN
$pwd = "wasuptid";	# password de acceso a la web

$dest = "0658068996";

$msg = "texto+del+mensaje";

$sms->EnviaMensaje($log, $pwd, $dest, $msg);

?>
