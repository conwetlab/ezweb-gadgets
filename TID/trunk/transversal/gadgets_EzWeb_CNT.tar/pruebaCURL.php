<?php
// The usual - init a curl session and set the url
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://pc084254.hi.inet:7001/wasup/data/alarmTypes/');

// Set your login and password for authentication
curl_setopt($ch, CURLOPT_USERPWD, 'pjm:0mlpela0');

// You can use CURLAUTH_BASIC, CURLAUTH_DIGEST, CURLAUTH_GSSNEGOTIATE,
// CURLAUTH_NTLM, CURLAUTH_ANY, and CURLAUTH_ANYSAFE
//
// You can use the bitwise | (or) operator to combine more than one method.
// If you do this, CURL will poll the server to see what methods it supports and pick the best one.
//
// CURLAUTH_ANY is an alias for CURLAUTH_BASIC | CURLAUTH_DIGEST |
// CURLAUTH_GSSNEGOTIATE | CURLAUTH_NTLM
//
// CURLAUTH_ANYSAFE is an alias for CURLAUTH_DIGEST | CURLAUTH_GSSNEGOTIATE |
// CURLAUTH_NTLM
//
// Personally I prefer CURLAUTH_ANY as it covers all bases
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);

// This is occassionally required to stop CURL from verifying the peer�s certificate.
// CURLOPT_SSL_VERIFYHOST may also need to be TRUE or FALSE if
// CURLOPT_SSL_VERIFYPEER is disabled (it defaults to 2 - check the existence of a
// common name and also verify that it matches the hostname provided)
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

// Optional: Return the result instead of printing it
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// The usual - get the data and close the session
$data = curl_exec($ch);
curl_close($ch); 
//print('jau');
print($data);
?> 