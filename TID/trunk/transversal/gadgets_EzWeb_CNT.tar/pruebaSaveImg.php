<?php

function fopen_recursive($path, $mode, $chmod=0777){
  preg_match('`^(.+)/([a-zA-Z0-9_]+\.[a-z]+)$`i', $path, $matches);
//  print_r($matches);
  $directory = $matches[1];
  $file = $matches[2];

//  print "\nFILE: $file \n";
//  print "\nDIR: $directory \n";

  if (!is_dir($directory)){
    if (!mkdir($directory, $chmod, 1)){
    return FALSE;
    }
  }
 return fopen ($path, $mode);
}


// Get page
// $url = "http://farm3.static.flickr.com/2375/2448764554_58b707321a.jpg";
$url = $_POST['url'];
if ($url == '') {
   $url = "http://farm3.static.flickr.com/2375/2448764554_58b707321a.jpg";
}

print "<br/>URL: $url";

$gestorFile = file($url);
$data = implode("", $gestorFile); 

$path_info = parse_url($url);
//print_r($path_info);

$myFile = "/tmp" . $path_info['path'];
print "<br/>Local FILE: $myFile";
 

if(file_exists($myFile))
{
   unlink($myFile);
}

$fh = fopen_recursive($myFile, 'xb') or die("can't open file");
fwrite($fh, $data);
fclose($fh);
?>
