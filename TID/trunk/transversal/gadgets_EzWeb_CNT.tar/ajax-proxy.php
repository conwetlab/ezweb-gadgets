<?php
/**
 * AJAX Cross Domain (PHP) Proxy 0.6
 *    by Iacovos Constantinou (http://www.iacons.net)
 * 
 * Released under CC-GNU GPL
 */

/**
 * Enables or disables filtering for cross domaing requests.
 * Recommended value: true, for security reasons
 */
define('CSAJAX_FILTERS', true);


/**
 * A set of valid cross domain requests
 */
/*$valid_requests = array(
    'http://www.example.com',
    'http://www.csdomain.com',
	'http://demo.wasup.morfeo-project.org:7001/wasup/data/alarmTypes/',
	'http://coco.hi.inet:6001/wasup/data/alarmTypes/'
);*/

/*** STOP EDITING HERE UNLESS YOU KNOW WHAT YOU ARE DOING ***/

// identify request headers
$request_headers = array();
foreach ( $_SERVER as $key=>$value ) {
    if( substr($key, 0, 5) == 'HTTP_' ) {
        $headername = str_replace('_', ' ', substr($key, 5));
        $headername = str_replace(' ', '-', ucwords(strtolower($headername)));
        $request_headers[$headername] = $value;
    }
}

//$authentication_credentials = false;

// identify request method, url and params
$request_method = $_SERVER['REQUEST_METHOD'];
$request_params = ( $request_method == 'GET' ) ? $_GET : $_POST;
$request_url    = urldecode($request_params['url']);
$request_method = urldecode($request_params['method']);
$p_request_url    = parse_url($request_url);
unset($request_params['url']);
unset($request_params['method']);

// ignore requests for proxy :)
if ( preg_match('!'. $_SERVER['SCRIPT_NAME'] .'!', $request_url) || empty($request_url) ) {
    exit;
}
    
// check against valid requests
if ( CSAJAX_FILTERS ) {
    $parsed     = $p_request_url;
    $check_url  = isset($parsed['scheme']) ? $parsed['scheme'] .'://' : '';
    $check_url .= isset($parsed['user']) ? $parsed['user'] . ($parsed['pass'] ? ':'. $parsed['pass']:'') .'@' : '';
    $check_url .= isset($parsed['host']) ? $parsed['host'] : '';
    $check_url .= isset($parsed['port']) ? ':'.$parsed['port'] : '';
    $check_url .= isset($parsed['path']) ? $parsed['path'] : '';
    /*if ( !in_array($check_url, $valid_requests) ) {
		print('URL not in valid_request lists');
        exit;
    }*/
}

// append query string for GET requests
if ( $request_method == 'GET' && count($request_params) > 0 && ( !array_key_exists('query', $p_request_url) || empty($p_request_url['query']) ) ) {
    $request_url .= '?'. http_build_query($request_params);
}
/*if ( $request_method == 'POST' && count($request_params) > 0 && ( !array_key_exists('query', $p_request_url) || empty($p_request_url['query']) ) ) {
    //$request_post_params .= http_build_query($request_params);
	print($request_params);
	foreach ( $request_params as $key => $value ) {
		//print_r($key);
		$request_post_params .= '&'.$key.'='.$value;
	}
}*/


//print_r($request_post_params);

// let the request begin
//print($request_url);
$ch = curl_init($request_url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
// Set your login and password for authentication
if (isset($_SERVER['PHP_AUTH_USER'])) {
    //echo "<p>Hello {$_SERVER['PHP_AUTH_USER']}.</p>";
    //echo "<p>You entered {$_SERVER['PHP_AUTH_PW']} as your password.</p>";
	curl_setopt($ch, CURLOPT_USERPWD, "{$_SERVER['PHP_AUTH_USER']}:{$_SERVER['PHP_AUTH_PW']}");
	//print_r($request_headers);
}

curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);

//curl_setopt($ch, CURLOPT_COOKIEFILE, "/tmp/cookiefile");
//curl_setopt($ch, CURLOPT_COOKIEJAR, "/tmp/cookiefile"); # SAME cookiefile
//print_r($request_headers);
curl_setopt($ch, CURLOPT_HTTPHEADER, apache_request_headers());            // (re-)send request's headers
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                    // return response
curl_setopt($ch, CURLOPT_HEADER, true);                            // enabled response headers

// add post data for POST requests
if ( $request_method == 'POST' ) {
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $request_params);
}

//print_r(apache_request_headers());

// retrieve response (headers and content)
$response = curl_exec($ch);

$response_http_code = curl_getinfo($ch,CURLINFO_HTTP_CODE);
//print(curl_getinfo($ch,CURLINFO_HTTP_CODE));

curl_close($ch);

//print($response);


// split response to header and content


if (isset($_SERVER['PHP_AUTH_USER'])) {
	list($response_headers_auth, $response_headers, $response_content) = preg_split('/(\r\n){2}/', $response, 3);
	//print($response_header_content);
	//print($response_content);
} else {
	list($response_headers, $response_content) = preg_split('/(\r\n){2}/', $response, 2);
}

// (re-)send response's headers
$response_headers = preg_split('/(\r\n){1}/', $response_headers);
//print_r($response_headers);
foreach ( $response_headers as $key => $response_header ) {
    //if (authentication_credentials) {
	/*if (isset($_SERVER['PHP_AUTH_USER']) && $response_http_code == 200) {
		
		if ( !preg_match('/HTTP\/1.1 401/', $response_header)) {
			//echo ("Jau\n $response_header");
			//print("Ou\n $response_http_code");
			header($response_header, false, 200);
			//echo (i);
			//break;
		} else {
			//echo ("Jarrrl\n $response_header");
			//print("Ou\n $response_http_code");
			//header($response_header, false, 200);
			//echo (j);
			//break;
		}
	} else*/
	if ( !preg_match('/^(Transfer-Encoding):/', $response_header))  {
        header($response_header);
		//print("\n $response_header");
	}
}
// finally, output the content
//print('before end');
print($response_content);
// && !preg_match('/^(HTTP/1.1 401):/', $response_header)
?> 