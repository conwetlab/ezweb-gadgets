<?php
//phpinfo(); 

include "APIMMS.php";

set_time_limit(600);

$mms = new MensajeriaMultimediaWeb();

$log = "639839273";	// MSISDN
$passw = "wasuptid";	// password de acceso a la web de copiagenda

$user = $mms->Login($log, $passw);
if($user == "")
{
    print "Error de Login";
}
else
{
    $nombreImg = "foto"; // nombre de la imagen que vamos a insertar
    $pathImg = "/home/pjm/OMF/localizame.png"; // path de la imagen que vamos a insertar
    $mms->InsertaImagen($nombreImg, $pathImg);

    // $nombreSnd="audio"; // nombre del sonido que vamos a insertar
    //$pathSnd="c:\\sounds\\tono.mid"; // path del sonido que vamos a insertar
    //$mms->InsertaAudio($nombreSnd, $pathSnd);

    // Si ya hemos insertado una imagen o un sonido no debemos insertar un v�deo
    //$nombreVid="video"; // nombre del v�deo que vamos a insertar
    //$pathVid="c:\\videos\\vid.avi"; // path del v�deo que vamos a insertar
    //$mms->InsertaVideo($nombreVid, $pathVid);

    $dest = "658068996"; // destinatario del mensaje
    $subject = "Prueba"; // asunto del mensaje
    $msg = "texto+del+mensaje"; // texto del mensaje
    $mms->EnviaMensaje($subject, $dest, $msg);

    $mms->Logout();
}
?>
