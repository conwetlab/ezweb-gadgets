<?php

class MensajeriaMultimediaWeb
{
    var $login;
    var $user;
    var $sk;
    var $cookie;
    var $server;

    # Realiza el login al servicio MMS
    function Login($loginini, $pwd)
    {
	print "Iniciando Login...<br>";
    	$server = "www.multimedia.movistar.es";
    	
	$ch = curl_init();
	$url = "http://$server/";
	curl_setopt ($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,false);

	$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);

	// Intentamos entrar en www.multimedia.movistar.es para que nos diga a cual tenemos que ir
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, false);
	curl_setopt($ch, CURLOPT_GET, true);
	// cabeceras HTTP
	$header = array("Accept-Encoding: identity",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($code == 302)
        {
	    // Nos redirecionan y nos dan una cookie
            list($header, $result) = explode("\n\n", $result, 2);

	    $matches = array();
	    preg_match('/Location:(.*?)\n/', $header, $matches);
	    $url = @parse_url(trim(array_pop($matches)));

	    $this->server = $url['host'];
	    $this->login = $loginini;
	    
	    $url = "http://$this->server/login";
	    $res= curl_setopt ($ch, CURLOPT_URL,$url);
	    curl_setopt($ch, CURLOPT_POST, true);
	    curl_setopt($ch, CURLOPT_GET, false);
	    $postdata = "source=olduid&TM_ACTION=LOGIN&TM_LOGIN=$this->login&TM_PASSWORD=$pwd";
	    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	    # cabeceras HTTP
	    $header = array("Content-type: application/x-www-form-urlencoded",
	    		    "Content-Length: ".strlen($postdata),
	    		    "Accept-Encoding: identity",
	    		    "Connection: Keep-Alive");
	    curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	    $result = curl_exec ($ch);
	    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($code == 302)
            {
		// Nos redirecionan y nos dan una cookie
	        list($header, $result) = explode("\n\n", $result, 2);

		$matches = array();
		preg_match('/Location:(.*?)\n/', $header, $matches);
		$url = @parse_url(trim(array_pop($matches)));

	        $listaparam=split("&",$url['query']);
	        $sklist=split("=",$listaparam[0]);
	        $this->sk = $sklist[1];
	    	print " - sk: ".$this->sk."<br>";
	        $uidlist=split("=",$listaparam[1]);
	        $this->user = $uidlist[1];
	    	print " - uid: ".$this->user."<br>";
	        
		$new_url = $url['scheme'] . '://' . $url['host'] . $url['path'] . ($url['query']?'?'.$url['query']:'');

		$matches = array();
		preg_match('/Set-Cookie:skf=(.*?)\n/', $header, $matches);
	    	list($cookie_value, $rest) = explode("; ", $matches[1], 2);
	    	$this->cookie = $cookie_value;
	    	print " - Cookie: ".$this->cookie."<br>";
	    	
	    	if($this->user != "")
	    	{
	            $url = "http://$this->server/main/?sk=$this->sk&uid=$this->user&source=&olduid=";
	            $res = curl_setopt ($ch, CURLOPT_URL,$url);
	            curl_setopt($ch, CURLOPT_POST, false);
	            curl_setopt($ch, CURLOPT_GET, true);
	            // cabeceras HTTP
	            $header = array("Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*",
	    		            "Cookie: skf=$this->cookie",
	    		            "Accept-Encoding: identity",
	    		            "Connection: Keep-Alive");
	            curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	            $result = curl_exec ($ch);
	            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if ($code == 200)
                    {
	                $url = "http://$this->server/compose/send?uid=$this->user&sk=$this->sk";
	                $res = curl_setopt ($ch, CURLOPT_URL,$url);
	                curl_setopt($ch, CURLOPT_POST, false);
	                curl_setopt($ch, CURLOPT_GET, true);
	                // cabeceras HTTP
	                $header = array("Accept: */*",
	    		                "Cookie: skf=$this->cookie",
	    		                "Accept-Encoding: identity",
	    		                "Connection: Keep-Alive");
	                curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	                $result = curl_exec ($ch);
                    }
	    	}
            }

	}
	curl_close($ch);
	return $this->user;
    }

    // Inserta una imagen en el mensaje MMS
    function InsertaImagen($nombreObj, $pathObj)
    {
        $contentTypes["gif"] = "image/gif";
        $contentTypes["jpg"] = "image/pjpeg";
        $contentTypes["jpeg"] = "image/pjpeg";
        $contentTypes["png"] = "image/x-png";
        $contentTypes["bmp"] = "image/bmp";
        // en principio s�lo enviaremos estos tipos
        
        $path = split("\.", $pathObj);
        $count = count($path);
        $extension = $path[$count-1];
        $contentType = $contentTypes[$extension];

	print "Insertando imagen...<br>";
        
	$ch = curl_init();
	$url = "http://$server/";
	curl_setopt ($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,false);

	$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);

	$url = "http://$this->server/compose/ms";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_GET, false);
	$postdata = "uid=$this->user&sk=$this->sk&slide_num=1&function_name=&text_function=update&dialog_url=&text_value=";
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	// cabeceras HTTP
        $referer = "http://$this->server/compose/slide?uid=$this->user&sk=$this->sk&slide_num=1";
	$header = array("Accept: */*",
			"Accept-Encoding: gzip, deflate",
			"Cookie: skf=$this->cookie",
			"Referer: $referer",
			"Content-Type: ",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);

	$url = "http://$this->server/folders/upload_frame?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=1&rnd=74065";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, false);
	curl_setopt($ch, CURLOPT_GET, true);
	// cabeceras HTTP
        $referer = "http://$this->server/folders/upload?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=1";
	$header = array("Accept: */*",
			"Accept-Encoding: gzip, deflate",
			"Cookie: skf=$this->cookie",
			"Referer: $referer",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($code == 200)
        {
            $separador = "---------------------------7d77df567a4b9";

            // generamos los datos del objeto
            $userPart = "--$separador\r\nContent-Disposition: form-data; name=\"user\"\r\n\r\n34$this->login\r\n";
            $limitPart = "--$separador\r\nContent-Disposition: form-data; name=\"limit\"\r\n\r\n307200\r\n";

            $urlReturn = "http://$this->server/folders/upload_close?uid=$this->user&sk=$this->sk&uploadtofolder=false";
            $urlReturnPart = "--$separador\r\nContent-Disposition: form-data; name=\"url_return\"\r\n\r\n$urlReturn\r\n";

            $namePart = "--$separador\r\nContent-Disposition: form-data; name=\"name\"\r\n\r\n$nombreObj\r\n";
            $filenamePart = "--$separador\r\nContent-Disposition: form-data; name=\"filename\"; filename=\"$pathObj\"\r\nContent-Type: $contentType\r\n\r\n";

            $final = "\r\n--$separador--\r\n";
            
            $contenido = file_get_contents($pathObj);

            $data = $userPart.$limitPart.$urlReturnPart.$namePart.$filenamePart.$contenido.$final;

	    $url = "http://$this->server/mas/messaging_as/temporalcontentservlet";
	    $res= curl_setopt ($ch, CURLOPT_URL,$url);
	    curl_setopt($ch, CURLOPT_POST, true);
	    curl_setopt($ch, CURLOPT_GET, false);
	    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            // es necesario crear la cabecera Referer con los par�metros de la petici�n anterior
            $referer = "http://$this->server/folders/upload_frame?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=1&rnd=74065";
	    // cabeceras HTTP
            $contentType = "multipart/form-data; boundary=$separador";
	    $header = array("Content-Type: $contentType",
	    		    "Accept-Language: es",
	    		    "Accept: */*",
			    "Accept-Encoding: gzip, deflate",
			    "Cookie: skf=$this->cookie",
			    "Cache-Control: no-cache",
			    "Referer: $referer",
	    		    "Connection: Keep-Alive");
	    curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	    $result = curl_exec ($ch);

	    list($header, $result) = explode("\r\n\r\n", $result, 2);

	    $matches = array();
	    preg_match('/oid:(.*?)\n/', $header, $matches);
	    $oidaux = trim($matches[1]);
	    $oid = str_replace("/","%2F",$oidaux);
	    print " - oid = ".$oid."<br>";

	    if($oid != "")
	    {
                print " - Imagen insertada<br>";
	        $url = "http://$this->server/folders/upload_close?uploadtofolder=false&uid=$this->user&sk=$this->sk&status=success&oid=$oid";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
                $referer = "http://$this->server/folders/upload?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=1";
	        $header = array("Accept: */*",
			        "Accept-Encoding: gzip, deflate",
			        "Cookie: skf=$this->cookie",
			        "Referer: $referer",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);

	        $url = "http://$this->server/compose/ms?uid=$this->user&sk=$this->sk&slide_num=1&function_name=img&value=$oid";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
                $referer = "http://$this->server/compose?uid=$this->user&sk=$this->sk&fr=ns&pathstring=+:+Env%EDo+Mensaje+MultiMedia&adultcheckparam=no";
	        $header = array("Accept: */*",
			        "Accept-Encoding: gzip, deflate",
			        "Cookie: skf=$this->cookie",
			        "Referer: $referer",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);
	    }
        }

        curl_close($ch);
    }

    // Inserta un archivo de audio en el mensaje MMS
    function InsertaAudio($nombreObj, $pathObj)
    {
        $contentTypes["mid"] = "audio/mid";
        $contentTypes["wav"] = "audio/wav";
        $contentTypes["mp3"] = "audio/mpeg";
        // en principio s�lo enviaremos estos tipos
        
        $path = split("\.", $pathObj);
        $count = count($path);
        $extension = $path[$count-1];
        $contentType = $contentTypes[$extension];

	print "Insertando audio...<br>";
        
	$ch = curl_init();
	$url = "http://$server/";
	curl_setopt ($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,false);

	$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);

	$url = "http://$this->server/compose/ms";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_GET, false);
	$postdata = "uid=$this->user&sk=$this->sk&slide_num=1&function_name=&text_function=update&dialog_url=&text_value=";
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	// cabeceras HTTP
        $referer = "http://$this->server/compose/slide?uid=$this->user&sk=$this->sk&slide_num=1";
	$header = array("Accept: */*",
			"Accept-Encoding: gzip, deflate",
			"Cookie: skf=$this->cookie",
			"Referer: $referer",
			"Content-Type: ",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);

	$url = "http://$this->server/folders/upload_frame?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=2&rnd=74065";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, false);
	curl_setopt($ch, CURLOPT_GET, true);
	// cabeceras HTTP
        $referer = "http://$this->server/folders/upload?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=2";
	$header = array("Accept: */*",
			"Accept-Encoding: gzip, deflate",
			"Cookie: skf=$this->cookie",
			"Referer: $referer",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($code == 200)
        {
            $separador = "---------------------------7d77df567a4b9";

            // generamos los datos del objeto
            $userPart = "--$separador\r\nContent-Disposition: form-data; name=\"user\"\r\n\r\n34$this->login\r\n";
            $limitPart = "--$separador\r\nContent-Disposition: form-data; name=\"limit\"\r\n\r\n307200\r\n";

            $urlReturn = "http://$this->server/folders/upload_close?uid=$this->user&sk=$this->sk&uploadtofolder=false";
            $urlReturnPart = "--$separador\r\nContent-Disposition: form-data; name=\"url_return\"\r\n\r\n$urlReturn\r\n";

            $namePart = "--$separador\r\nContent-Disposition: form-data; name=\"name\"\r\n\r\n$nombreObj\r\n";
            $filenamePart = "--$separador\r\nContent-Disposition: form-data; name=\"filename\"; filename=\"$pathObj\"\r\nContent-Type: $contentType\r\n\r\n";

            $final = "\r\n--$separador--\r\n";
            
            $contenido = file_get_contents($pathObj);

            $data = $userPart.$limitPart.$urlReturnPart.$namePart.$filenamePart.$contenido.$final;

	    $url = "http://$this->server/mas/messaging_as/temporalcontentservlet";
	    $res= curl_setopt ($ch, CURLOPT_URL,$url);
	    curl_setopt($ch, CURLOPT_POST, true);
	    curl_setopt($ch, CURLOPT_GET, false);
	    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            // es necesario crear la cabecera Referer con los par�metros de la petici�n anterior
            $referer = "http://$this->server/folders/upload_frame?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=2&rnd=74065";
	    // cabeceras HTTP
            $contentType = "multipart/form-data; boundary=$separador";
	    $header = array("Content-Type: $contentType",
	    		    "Accept-Language: es",
	    		    "Accept: */*",
			    "Accept-Encoding: gzip, deflate",
			    "Cookie: skf=$this->cookie",
			    "Cache-Control: no-cache",
			    "Referer: $referer",
	    		    "Connection: Keep-Alive");
	    curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	    $result = curl_exec ($ch);

	    list($header, $result) = explode("\r\n\r\n", $result, 2);

	    $matches = array();
	    preg_match('/oid:(.*?)\n/', $header, $matches);
	    $oidaux = trim($matches[1]);
	    $oid = str_replace("/","%2F",$oidaux);
	    print " - oid = ".$oid."<br>";

	    if($oid != "")
	    {
                print " - Audio insertado<br>";
	        $url = "http://$this->server/folders/upload_close?uploadtofolder=false&uid=$this->user&sk=$this->sk&status=success&oid=$oid";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
                $referer = "http://$this->server/folders/upload?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=2";
	        $header = array("Accept: */*",
			        "Accept-Encoding: gzip, deflate",
			        "Cookie: skf=$this->cookie",
			        "Referer: $referer",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);

	        $url = "http://$this->server/compose/ms?uid=$this->user&sk=$this->sk&slide_num=1&function_name=audio&value=$oid";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
                $referer = "http://$this->server/compose?uid=$this->user&sk=$this->sk&fr=ns&pathstring=+:+Env%EDo+Mensaje+MultiMedia&adultcheckparam=no";
	        $header = array("Accept: */*",
			        "Accept-Encoding: gzip, deflate",
			        "Cookie: skf=$this->cookie",
			        "Referer: $referer",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);
	    }
        }

        curl_close($ch);
    }

    // Inserta un archivo de v�deo en el mensaje MMS
    function InsertaVideo($nombreObj, $pathObj)
    {
        $contentTypes["avi"] = "video/avi";
        $contentTypes["asf"] = "video/x-ms-asf";
        $contentTypes["mpg"] = "video/mpeg";
        $contentTypes["mpeg"] = "video/mpeg";
        $contentTypes["wmv"] = "video/x-ms-wmv";
        
        $path = split("\.", $pathObj);
        $count = count($path);
        $extension = $path[$count-1];
        $contentType = $contentTypes[$extension];

	print "Insertando video...<br>";
        
	$ch = curl_init();
	$url = "http://$server/";
	curl_setopt ($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,false);

	$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);

	$url = "http://$this->server/compose/ms";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_GET, false);
	$postdata = "uid=$this->user&sk=$this->sk&slide_num=1&function_name=&text_function=update&dialog_url=&text_value=";
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	// cabeceras HTTP
        $referer = "http://$this->server/compose/slide?uid=$this->user&sk=$this->sk&slide_num=1";
	$header = array("Accept: */*",
			"Accept-Encoding: gzip, deflate",
			"Cookie: skf=$this->cookie",
			"Referer: $referer",
			"Content-Type: ",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);

	$url = "http://$this->server/folders/upload_frame?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=3&rnd=74065";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, false);
	curl_setopt($ch, CURLOPT_GET, true);
	// cabeceras HTTP
        $referer = "http://$this->server/folders/upload?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=3";
	$header = array("Accept: */*",
			"Accept-Encoding: gzip, deflate",
			"Cookie: skf=$this->cookie",
			"Referer: $referer",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($code == 200)
        {
            $separador = "---------------------------7d77df567a4b9";

            // generamos los datos del objeto
            $userPart = "--$separador\r\nContent-Disposition: form-data; name=\"user\"\r\n\r\n34$this->login\r\n";
            $limitPart = "--$separador\r\nContent-Disposition: form-data; name=\"limit\"\r\n\r\n307200\r\n";

            $urlReturn = "http://$this->server/folders/upload_close?uid=$this->user&sk=$this->sk&uploadtofolder=false";
            $urlReturnPart = "--$separador\r\nContent-Disposition: form-data; name=\"url_return\"\r\n\r\n$urlReturn\r\n";

            $namePart = "--$separador\r\nContent-Disposition: form-data; name=\"name\"\r\n\r\n$nombreObj\r\n";
            $filenamePart = "--$separador\r\nContent-Disposition: form-data; name=\"filename\"; filename=\"$pathObj\"\r\nContent-Type: $contentType\r\n\r\n";

            $final = "\r\n--$separador--\r\n";
            
            $contenido = file_get_contents($pathObj);

            $data = $userPart.$limitPart.$urlReturnPart.$namePart.$filenamePart.$contenido.$final;

	    $url = "http://$this->server/mas/messaging_as/temporalcontentservlet";
	    $res= curl_setopt ($ch, CURLOPT_URL,$url);
	    curl_setopt($ch, CURLOPT_POST, true);
	    curl_setopt($ch, CURLOPT_GET, false);
	    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            // es necesario crear la cabecera Referer con los par�metros de la petici�n anterior
            $referer = "http://$this->server/folders/upload_frame?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=3&rnd=74065";
	    // cabeceras HTTP
            $contentType = "multipart/form-data; boundary=$separador";
	    $header = array("Content-Type: $contentType",
	    		    "Accept-Language: es",
	    		    "Accept: */*",
			    "Accept-Encoding: gzip, deflate",
			    "Cookie: skf=$this->cookie",
			    "Cache-Control: no-cache",
			    "Referer: $referer",
	    		    "Connection: Keep-Alive");
	    curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	    $result = curl_exec ($ch);

	    list($header, $result) = explode("\r\n\r\n", $result, 2);

	    $matches = array();
	    preg_match('/oid:(.*?)\n/', $header, $matches);
	    $oidaux = trim($matches[1]);
	    $oid = str_replace("/","%2F",$oidaux);
	    print " - oid = ".$oid."<br>";

	    if($oid != "")
	    {
                print " - Video insertado<br>";
	        $url = "http://$this->server/folders/upload_close?uploadtofolder=false&uid=$this->user&sk=$this->sk&status=success&oid=$oid";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
                $referer = "http://$this->server/folders/upload?uid=$this->user&sk=$this->sk&folderid=&uploadtofolder=false&foldertype=3";
	        $header = array("Accept: */*",
			        "Accept-Encoding: gzip, deflate",
			        "Cookie: skf=$this->cookie",
			        "Referer: $referer",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);

	        $url = "http://$this->server/compose/ms?uid=$this->user&sk=$this->sk&slide_num=1&function_name=video&value=$oid";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
                $referer = "http://$this->server/compose?uid=$this->user&sk=$this->sk&fr=ns&pathstring=+:+Env%EDo+Mensaje+MultiMedia&adultcheckparam=no";
	        $header = array("Accept: */*",
			        "Accept-Encoding: gzip, deflate",
			        "Cookie: skf=$this->cookie",
			        "Referer: $referer",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);
	    }
        }

        curl_close($ch);
    }

    // Realiza el env�o del mensaje MMS
    function EnviaMensaje($subject, $dest, $msg)
    {
	$ch = curl_init();
	curl_setopt ($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,false);

	$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);

        print "Enviando mensaje...<br>";

        // Enviamos el mensaje
	$url = "http://$this->server/compose/ms";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_GET, false);
	$postdata = "user=$this->user&sk=$this->sk&function_name=send&text_function=update&text_value=$msg&slide_num=1&subject=$subject&to1=$dest&to2=&to3=&frag=";
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	// cabeceras HTTP
	$referer = "http://$this->server/compose?uid=$this->user&sk=$this->sk&fr=ns&pathstring= : Env�o Mensaje MultiMedia&adultcheckparam=no";
	$header = array("Content-Type: application/x-www-form-urlencoded",
	   		"Referer: $referer",
			"Accept-Language: es",
			"Accept-Encoding: gzip, deflate",
			"Cache-Control: no-cache",
	   		"Content-Length: ".strlen($postdata),
	    		"Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*",
	    		"Cookie: skf=$this->cookie",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);
	$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if(ereg("is_sent_ok=true",$result))
        {
            print " - Mensaje enviado<br>";
        }
        else
        {
            print " - El mensaje no se ha podido enviar<br>";
        }

	if($code == 200)
	{
	    $url = "http://$this->server/compose/send/confirm?uid=$this->user&sk=$this->sk&is_sent_ok=true&to1=$this->dest";
	    $res= curl_setopt ($ch, CURLOPT_URL,$url);
	    curl_setopt($ch, CURLOPT_POST, false);
	    curl_setopt($ch, CURLOPT_GET, true);
	    // cabeceras HTTP
	    $header = array("Accept: */*",
	    		    "Cookie: skf=$this->cookie",
	    		    "Connection: Keep-Alive");
	    curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	    $result = curl_exec ($ch);
	    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	    
	    if($code == 200)
	    {
	        $url = "http://$this->server/login_frame?uid=$this->user&sk=$this->sk";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
	        $header = array("Accept: */*",
	    		        "Cookie: skf=$this->cookie",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);

	        $url = "http://$this->server/compose?uid=$this->user&sk=$this->sk&fr=ns&pathstring=+%3A+Env%EDo+Mensaje+Multimedia&adultcheckparam=no";
	        $res= curl_setopt ($ch, CURLOPT_URL,$url);
	        curl_setopt($ch, CURLOPT_POST, false);
	        curl_setopt($ch, CURLOPT_GET, true);
	        // cabeceras HTTP
	        $header = array("Accept: */*",
	    		        "Cookie: skf=$this->cookie",
	    		        "Connection: Keep-Alive");
	        curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	        $result = curl_exec ($ch);
	    }
        }

	curl_close($ch);	
    }

    // Realiza el logout del servicio
    function Logout()
    {
	print "Iniciando Logout...<br>";
	$ch = curl_init();
	curl_setopt ($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,false);

	$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
	curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
	curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
	curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
	
        # hacemos el logout
	$url = "http://$this->server/logout";
	$res= curl_setopt ($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_GET, false);
	$postdata = "uid=$this->user&sk=$this->sk&TM_ACTION=LOGOUT";
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
	# cabeceras HTTP
	$referer = "http://".$this->server."/main/?sk=$this->sk&uid=$this->user&source=&olduid=";
	$header = array("Content-type: application/x-www-form-urlencoded",
	   		"Referer: ".$referer,
	   		"Content-Length: ".strlen($postdata),
	    		"Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/vnd.ms-powerpoint, application/msword, */*",
	    		"Connection: Keep-Alive");
	curl_setopt ($ch, CURLOPT_HTTPHEADER, $header);
	$result = curl_exec ($ch);

	curl_close($ch);	
    }
}
?>
