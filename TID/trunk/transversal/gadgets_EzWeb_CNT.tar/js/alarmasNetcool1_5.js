//IMPORTANT: user preference stores servlet_url base uri. It must be set by user
var servlet_url = EzWebAPI.createRGadgetVariable("resource_url", setBaseURI);

var node = EzWebAPI.createRWGadgetVariable("node");
var tipoCircuito = EzWebAPI.createRWGadgetVariable("tipoCircuito");
var direccionRed = EzWebAPI.createRWGadgetVariable("direccionRed");
var direccionIp = EzWebAPI.createRWGadgetVariable("direccionIp");
var heightInPixels = EzWebAPI.createRGadgetVariable("heightInPixels", setHeightInPixels);
var height = EzWebAPI.createRGadgetVariable("height", setVars3);

var i = 0;

//updates servlet_url var when user preference is updated
function setBaseURI(){
	loadData();
	return;
}//setBaseURI

function setHeightInPixels(){
	alert ('hieght');
}

function setVars3(){
	alert (height.get());
}

function successHandler(transport){
	i = i + 1;
	document.getElementById("info").innerHTML=transport.responseText;
	//Seting event properties
	value.set('prueba' + i);
	description.set('desc_prueba' + i);
	return;
}//successHandler

function errorHandler(){
	alert('An error occurred while sending get.\nPlease, Contact admin.');
	return;
}//errorHandler

function loadData(){
	var uri = servlet_url.get();
	//EzWebAPI.send_get(uri, this, successHandler, errorHandler);
	document.getElementById('topic-grid').innerHTML = '';
	createGrid();
}

function alarmSelected(){
	alert('Selected');
}

function escapar(cadena) {
	if (cadena==null) return null;
	cadena = cadena.replace(/\u20AC/gi,'\u0080');
	cadena = escape(cadena);
	cadena = cadena.replace(/\+/g,'%2B');
	return cadena;
}

function handleRowSelect(selectionModel, rowIndex, selectedRecord) {
	var tmpNode = selectedRecord.get('node');
    node.set(tmpNode);
	tipoCircuito.set(selectedRecord.get('tipoCircuito'));
	direccionRed.set(selectedRecord.get('direccionRed'));
	direccionIp.set(selectedRecord.get('direccionIp'));
}

/*
 * Ext JS Library 2.0.2
 * Copyright(c) 2006-2008, Ext JS, LLC.
 * licensing@extjs.com
 * 
 * http://extjs.com/license
 */
function createGrid(){

	// create the Data Store
    var store = new Ext.data.Store({
        // load using script tags for cross domain, if the data in on the same domain as
        // this page, an HttpProxy would be better
        proxy: new Ext.data.ScriptTagProxy({
            url: 'http://ezwuc.hi.inet:7001/ezwuc/data/netcool/alarms'
        }),

        // create reader that reads the Topic records
        reader: new Ext.data.JsonReader({
            root: 'rows',
            totalProperty: 'tableSize',
            fields: [
                'node', 'summary', 'count', 'firstOccurrence', 'lastOccurrence', 
				'direccionRed', 'direccionIp', 'tipoCircuito', 'severity', 'acknowledged'
            ]
        }),

        // turn on remote sorting
        remoteSort: true
    });
    store.setDefaultSort('lastOccurrence', 'desc');
	store.proxy.url = servlet_url.get();

    // the column model has information about grid columns
    // dataIndex maps the column to the specific data field in
    // the data store
    var cm = new Ext.grid.ColumnModel([{
           id: 'node', // id assigned so we can apply custom css (e.g. .x-grid-col-topic b { color:#333 })
           header: 'Node',
           dataIndex: 'node',
		   width: 100
         },{
		   id: 'summary',
           header: 'Summary',
           dataIndex: 'summary',
		   width: 600
		},{
           header: 'Count',
           dataIndex: 'count',
		   width: 100
        },{
           header: 'First Occurrence',
           dataIndex: 'firstOccurrence',
		   width: 120
        },{
           header: 'Last Occurrence',
           dataIndex: 'lastOccurrence',
		   width: 120
        }]);

    // by default columns are sortable
    cm.defaultSortable = true;
	
	// pluggable renders
    function renderNode(value, p, record){
        return String.format(
                '<b><a href="http://extjs.com/forum/showthread.php?t={2}" target="_blank">{0}</a></b><a href="http://extjs.com/forum/forumdisplay.php?f={3}" target="_blank">{1} Forum</a>',
                value, record.data.forumtitle, record.id, record.data.forumid);
    }

    var grid = new Ext.grid.GridPanel({
        el:'topic-grid',
        height:heightInPixels.get(),
        store: store,
        cm: cm,
		autoExpandColumn: 'summary',
        trackMouseOver:true,
        loadMask: true,
        bbar: new Ext.PagingToolbar({
            pageSize: 25,
            store: store,
            displayInfo: true,
            displayMsg: 'Displaying topics {0} - {1} of {2}',
            emptyMsg: "No topics to display",
        })
    });
	
	var gridView = new Ext.grid.GridView({ 
	    //forceFit: true, 
	    getRowClass : function (row, index) { 
	        var cls = ''; 
	        var data = row.data; 
	        switch (data.severity) { 
	            case '5' : 
	                cls = 'alarmGridCritical' 
	                break; 
	            case '4' : 
	                cls = 'alarmGridMajor' 
	                break;
				case '3' : 
	                cls = 'alarmGridMinor' 
	                break;
				case '2' : 
	                cls = 'alarmGridWarning' 
	                break;
				case '1' : 
	                cls = 'alarmGridIndeterm' 
	                break;
				case '0' : 
	                cls = 'alarmGridClear' 
	                break;
					
	        } 
	        return cls; 
	    } 
	});

	grid.view = gridView;
	
    // render it
    grid.render();
	
	grid.getSelectionModel().on('rowselect', handleRowSelect);
	
	grid.getSelectionModel().selectFirstRow();

    // trigger the data store load
    store.load({params:{start:0, limit:25}});

}



Ext.onReady(function(){
    createGrid();
});

