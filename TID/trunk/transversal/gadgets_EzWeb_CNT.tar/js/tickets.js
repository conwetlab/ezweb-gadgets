// Funciones de los tickets

// Inicio
function inicioBandejaEntrada()
{
	cargarBandejaEntrada();
}

// Cargar tabla de tickets
function cargarBandejaEntrada()
{
	var divTickets = document.getElementById("divTickets");
	mHTML = 
				"<table id=\"Tickets\" class=\"listTable\">" + "\n" +
				"\t" + "<tr>" + "\n";

	// Cabecera de la tabla
	for (indice=0; indice<=num_colums_visible; indice++)
	{
		mHTML += "\t" + "<th>" + tablaTickets[0][indice] + "</th>" + "\n";
	}

	// Datos de los tickets
	for (fila=1; fila<num_rows; fila++)
	{
		mHTML += "\t" + "</tr>" + "\n" +
				"\t" + "<tr id=" + fila + ">" + "\n";

		for (columna=0; columna<=num_colums_visible; columna++)
		{
			mHTML += "\t" + "<td>" + tablaTickets[fila][columna] + "</td>" + "\n";
		}
	}

	mHTML += "\t" + "</tr>" + "\n" +
 		 "</table>"

	divTickets.innerHTML = mHTML;
}

// Mostrar detalle ticket
function mostrarDetalleTicket(servicio)
{
	if (servicio != null)
	{
		var divDetalles = document.getElementById("divDetalles");

		for (fila=0; fila<num_rows; fila++)
		{
			if (servicio == tablaTickets[fila][columnServicio])
			{
				mHTML = "<table id=\"Detalles\" class=\"listTable\">" + "\n";

				for (columna=0; columna<num_colums; columna++)
				{
					mHTML += "\t" + "<tr id=" + fila + ">" + "\n" +
						 "\t" + "<td bgcolor=\"#E6E4E4\">" + "<b>" + tablaTickets[0][columna] + "</b></td>" + "\n" +
						 "\t" + "<td>" + tablaTickets[fila][columna] + "</td>" + "\n" +
						 "\t" + "</tr>" + "\n";
				}

				mHTML += "</table>"
			}
		}

		divDetalles.innerHTML = mHTML;
	}
}

// Mostrar datos agrupación
function mostrarAgrupacionTicket(servicio)
{
	var formAgrupacion   = document.getElementById('agrupacion');
	var indiceAgrupacion = formAgrupacion.listaAgrupacion.selectedIndex;
	var valorAgrupacion  = formAgrupacion.listaAgrupacion.options[indiceAgrupacion].value;

	// Crear tabla hash
	var hash = new Hash();

	for (fila=1; fila<num_rows; fila++)
	{
		var serv  = tablaTickets[fila][columnServicio];

		// Si es el servicio buscado
		if (serv == servicio)
		{
			switch (valorAgrupacion)
			{
				case Subestado:
					var clave = tablaTickets[fila][columnSubestado];
					if (hash.get(clave) == undefined)
						hash.set( clave, 1 );
					else
					{	
						var numOcurrencias = hash.get(clave) + 1;
						hash.set( clave, numOcurrencias );
					}
					break;
	
				case Producto:
					var clave = tablaTickets[fila][columnProducto];
					if (hash.get(clave) == undefined)
						hash.set( clave, 1 );
					else
					{	
						var numOcurrencias = hash.get(clave) + 1;
						hash.set( clave, numOcurrencias );
					}
					break;
	
				case FechaSolicitud:
					var clave = tablaTickets[fila][columnFechaSolicitud];
					if (hash.get(clave) == undefined)
						hash.set( clave, 1 );
					else
					{	
						var numOcurrencias = hash.get(clave) + 1;
						hash.set( clave, numOcurrencias );
					}
					break;
	
				case Criticidad:
					var clave = tablaTickets[fila][columnCriticidad];
					if (hash.get(clave) == undefined)
						hash.set( clave, 1 );
					else
					{	
						var numOcurrencias = hash.get(clave) + 1;
						hash.set( clave, numOcurrencias );
					}
					break;
			}
	
		}
	}

	var divResAgrupacion = document.getElementById("divResAgrupacion");

	mHTML = "<table id=\"resAgrupacion\" class=\"listTable\">" + "\n";
	mHTML += "\t" + "<th>Valor</th>" + "\n";
	mHTML += "\t" + "<th>Cantidad</th>" + "\n";

	var datos_grafico = "";

	hash.each(function(par){
		mHTML += "\t" + "<tr id=" + fila + ">" + "\n" +
			 "\t" + "<td bgcolor=\"#E6E4E4\">" + par.key + "</td>" + "\n" +
			 "\t" + "<td bgcolor=\"#E6E4E4\">" + par.value + "</td>" + "\n" +
			 "\t" + "</tr>" + "\n";

		if (datos_grafico != "")
		{
			datos_grafico += ", " + par.value;
		}
		else
		{
			datos_grafico = " " + par.value;
		}
	});

	mHTML += "</table>";

	divResAgrupacion.innerHTML = mHTML;

	// Grafico
	set_grafico_ticket(datos_grafico);
}

function mostrarGrafico(datos)
{
	var g=new GoogleChart();

	// Datos
	var array_datos = datos.split(",");
	var num_datos = array_datos.length;
	var matriz = new Array(1);
	matriz[0] = new Array(num_datos);

	for (i=0; i<num_datos; i++)
	{
		matriz[0][i] = parseInt(array_datos[i]);
	}

	// Minimo valor eje Y

	var minimo = 0;

	// Minimo valor eje Y

	var maximo = matriz[0].max();

	// Leyenda

        var leyenda = matriz[0].join("|");

	// Grafico
        g.init('campoGrafico'); //Target Div ID
        g.setChartType('bvs');  
        g.setChartTitle('Gráfico');
        g.setChartSize('300x140');  
        g.setChartColors('FF6600');
        g.setChartData(matriz, maximo);
        g.setLabels(leyenda);
	g.setAxisYRange(minimo, maximo);
        g.drawChart();
}

