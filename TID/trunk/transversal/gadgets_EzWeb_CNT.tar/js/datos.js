// Datos de la bandeja de entrada

var num_rows = 35;
var num_colums = 11;
var num_colums_visible = 7;

var columnServicio = 0;
var columnSubestado = 1;
var columnProducto = 2;
var columnFechaSolicitud = 6;
var columnCriticidad = 7;

var Subestado = "Subestado";
var Producto = "Producto";
var FechaSolicitud = "Fecha solicitud";
var Criticidad = "Criticidad";

var tablaTickets = new Array(num_rows);

tablaTickets[0] = new Array(num_colums);
tablaTickets[0] = ["Servicio", "Subestado", "Producto", "Mov", "ICM", "ANS", "Fecha solicitud", "Criticidad", "Impacto", "Urgencia", "Notas"];

tablaTickets[1] = new Array(num_colums);
tablaTickets[1] = ["28002312-019765", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Class (incluido bucle anal&oacute;gico) (2Mbits / 300kbits/s)", "A", "", "49", "08/05/2008", "Nivel 5", "Alto", "Media", ""];

tablaTickets[2] = new Array(num_colums);
tablaTickets[2] = ["28010783-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (4Mbits / 640kbits/s)", "M", "28010783-DP1", "50", "09/05/2008", "Nivel 5", "Alto", "Alta", "En curso"];

tablaTickets[3] = new Array(num_colums);
tablaTickets[3]=["28002877-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (4Mbits / 640kbits/s)", "M", "28002877-DP1", "50", "10/05/2008", "Nivel 5", "Alto", "Baja", "En curso"];

tablaTickets[4] =  new Array(num_colums);
tablaTickets[4]=["28002877-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Premium (incluido Bucle anal&oacute;gico) (2Mbit/s / 640kbit/s", "M", "28002877-DP1", "51", "10/05/2008", "Nivel 5", "Medio", "Media", "Pendiente revisar"];

tablaTickets[5] = new Array(num_colums);
tablaTickets[5]=["28000029-019774", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Premium (incluido Bucle anal&oacute;gico) (8Mbit/s / 640kbit/s", "A", "PRUEBA DESARROLLO", "51", "10/05/2008", "Nivel 5", "Media", "Baja", ""];

tablaTickets[6]  = new Array(num_colums);
tablaTickets[6]=["28000029-019773", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Premium (incluido Bucle anal&oacute;gico) (8Mbit/s / 640kbit/s", "A", "PRUEBA DESARROLLO", "51", "10/05/2008", "Nivel 5", "Alto", "Alta", ""];

tablaTickets[7] = new Array(num_colums);
tablaTickets[7]=["28039876-019785",  "PTE.ODP", "Acceso Internet No Educativo: ADSL opci&oacute;n Premium (incluido Bucle anal&oacute;gico) (8Mbit/s / 640kbit/s", "A", "EVA", "52", "11/05/2008", "Nivel 5", "Bajo", "Baja", ""];

tablaTickets[8] = new Array(num_colums);
tablaTickets[8]=["28037031B-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido Bucle anal&oacute;gico) (4Mbit/s / 640kbit/s", "M", "28037031B-DP1", "52", "11/05/2008", "Nivel 5", "Bajo", "Alta", "En curso"];

tablaTickets[9] = new Array(num_colums);
tablaTickets[9]=["28002944-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido Bucle anal&oacute;gico) (4Mbit/s / 640kbit/s", "M", "28002944-DP1", "52", "11/05/2008", "Nivel 5", "Bajo", "Baja", "En curso"];

tablaTickets[10]  = new Array(num_colums);
tablaTickets[10]=["28002890-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28002890-DP1", "52", "11/05/2008", "Nivel 5", "Alto", "Alta", "Pendiente recibir notificaci%oacute;n"];

tablaTickets[11]  = new Array(num_colums);
tablaTickets[11]=["28048282-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28048282-DP1", "52", "11/05/2008", "Nivel 5", "Medio", "Media", ""];

tablaTickets[12]  = new Array(num_colums);
tablaTickets[12]=["28048282-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Premium (incluido Bucle anal&oacute;gico) (2Mbit/s / 640kbit/s", "M", "28048282-DP1", "56", "12/05/2008", "Nivel 4", "Alto", "Alta", "Sin notas"];

tablaTickets[13]  = new Array(num_colums);
tablaTickets[13]=["28048282-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Premium (incluido Bucle anal&oacute;gico) (2Mbit/s / 640kbit/s", "A", "28048282-DP1", "26", "12/05/2008", "Nivel 3", "Medio", "Baja", "Sin notas"];

tablaTickets[14]  = new Array(num_colums);
tablaTickets[14]=["28048293-DP2", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28048293-DP2", "33", "12/05/2008", "Nivel 5", "Alto", "Alta", "En curso"];

tablaTickets[15]  = new Array(num_colums);
tablaTickets[15]=["28048293-DP2", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28048293-DP2", "33", "12/05/2008", "Nivel 5", "Medio", "Media", "Enviar a Mario"];

tablaTickets[16]  = new Array(num_colums);
tablaTickets[16]=["28048293-DP2", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28048293-DP2", "33", "12/05/2008", "Nivel 5", "Alto", "Baja", ""];

tablaTickets[17]  = new Array(num_colums);
tablaTickets[17]=["28048293-DP2", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28048293-DP2", "33", "12/05/2008", "Nivel 4", "Medio", "Alta", ""];

tablaTickets[18]  = new Array(num_colums);
tablaTickets[18]=["28048293-DP2", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28048293-DP2", "33", "12/05/2008", "Nivel 4", "Alto", "Alta", "Sin asignar"];

tablaTickets[19]  = new Array(num_colums);
tablaTickets[19]=["28048293-DP2", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 4Mbit/s / 640kbit/s", "M", "28048293-DP2", "33", "13/05/2008", "Nivel 5", "Bajo", "Baja", ""];

tablaTickets[20]  = new Array(num_colums);
tablaTickets[20]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "13/05/2008", "Nivel 5", "Medio", "Media", ""];

tablaTickets[21]  = new Array(num_colums);
tablaTickets[21]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "14/05/2008", "Nivel 5", "Medio", "Media", ""];

tablaTickets[22]  = new Array(num_colums);
tablaTickets[22]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "14/05/2008", "Nivel 5", "Alto", "Alta", ""];

tablaTickets[23]  = new Array(num_colums);
tablaTickets[23]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "14/05/2008", "Nivel 5", "Alto", "Alta", "Sin asignar"];

tablaTickets[24]  = new Array(num_colums);
tablaTickets[24]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "15/05/2008", "Nivel 5", "Medio", "Media", ""];

tablaTickets[25]  = new Array(num_colums);
tablaTickets[25]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "15/05/2008", "Nivel 5", "Bajo", "Baja", "Sin notas"];

tablaTickets[26]  = new Array(num_colums);
tablaTickets[26]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "15/05/2008", "Nivel 5", "Bajo", "Media", "Sin notas"];

tablaTickets[27]  = new Array(num_colums);
tablaTickets[27]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "15/05/2008", "Nivel 5", "Alto", "Alta", "Revisar"];

tablaTickets[28]  = new Array(num_colums);
tablaTickets[28]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "15/05/2008", "Nivel 5", "Medio", "Media", "No funciona el acceso desde el pasado 10/05/2008"];

tablaTickets[29]  = new Array(num_colums);
tablaTickets[29]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "15/05/2008", "Nivel 5", "Bajo", "Baja", ""];

tablaTickets[30]  = new Array(num_colums);
tablaTickets[30]=["28048290-DP1", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Avanzada (incluido 2Mbit/s / 640kbit/s", "M", "28048290-DP1", "55", "15/05/2008", "Nivel 5", "Medio", "Alta", ""];

tablaTickets[31] = new Array(num_colums);
tablaTickets[31] = ["28002312-019765", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Class (incluido bucle anal&oacute;gico) (2Mbits / 300kbits/s)", "A", "", "49", "16/05/2008", "Nivel 5", "Bajo", "Baja", "No ha sido posible contactar con el cliente"];

tablaTickets[32] = new Array(num_colums);
tablaTickets[32] = ["28002312-019765", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Class (incluido bucle anal&oacute;gico) (2Mbits / 300kbits/s)", "A", "", "49", "16/05/2008", "Nivel 5", "Bajo", "Baja", ""];

tablaTickets[33] = new Array(num_colums);
tablaTickets[33] = ["28002312-019765", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Class (incluido bucle anal&oacute;gico) (2Mbits / 300kbits/s)", "A", "", "49", "16/05/2008", "Nivel 5", "Alto", "Media", "El cliente est&aacute; ausente"];

tablaTickets[34] = new Array(num_colums);
tablaTickets[34] = ["28002312-019765", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Class (incluido bucle anal&oacute;gico) (2Mbits / 300kbits/s)", "A", "", "49", "16/05/2008", "Nivel 5", "Bajo", "Media", ""];

tablaTickets[35] = new Array(num_colums);
tablaTickets[35] = ["28002312-019765", "PTE.ODP", "Acceso Internet Educativo: ADSL opci&oacute;n Class (incluido bucle anal&oacute;gico) (2Mbits / 300kbits/s)", "A", "", "49", "16/05/2008", "Nivel 5", "Medio", "Media", ""];

