echo "Running OpenMovilForum Services"
nohup python code.py 8001 >trazas.log &
