import web

urls = (
    '/openmovilforum/mms', 'mms.MMSSenderSrv.view'
)

web.webapi.internalerror = web.debugerror
if __name__ == "__main__": web.run(urls, globals(), web.reloader)
